import java.util.Scanner;

public class studentDetails {

	public void saveDetails(Students st)
	{
		int total;
		double percentage = 0;
		
		/* Use getter to fetch and display the values */
		total = st.getMarks_math() + st.getMarks_english() + st.getMarks_science();
		percentage = ((double) total / (double) 300 ) * 100;
		System.out.println("Name = " + st.getName());
		System.out.println("Roll = " + st.getRoll());
		System.out.println("Maths = " + st.getMarks_math());
		System.out.println("Science = " + st.getMarks_science());
		System.out.println("English = " + st.getMarks_english());
		System.out.println("Total = " + total);
		System.out.println("Percentage = " + percentage + "%" );
	}
	
	public static void main(String[] args) {

//		Declaration of variables
		int count;
		int i = 0;
		String name = null;
		int roll;
		int marks_math;
		int marks_science;
		int marks_english;	

		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		System.out.println("Enter number of students: ");
		count = s.nextInt();

		do {
			
			System.out.println();
			System.out.println("Enter name of student:");
			name = s.next();
			System.out.println("Enter roll number:");
			roll = s.nextInt();
			System.out.println("Enter marks in Maths:");
			marks_math = s.nextInt();
			System.out.println("Enter marks in Science:");
			marks_science = s.nextInt();
			System.out.println("Enter marks in English:");
			marks_english = s.nextInt();
			
			/*Initialize constructor */
			Students st = new Students(name,roll,marks_math,marks_science,marks_english);
			
			/* Use setter to save values entered by user*/
			st.setName(name);
			st.setRoll(roll);
			st.setMarks_math(marks_math);
			st.setMarks_science(marks_science);
			st.setMarks_english(marks_english);
			
			studentDetails save = new studentDetails();
			save.saveDetails(st); /* Call method to display the values*/
			
			i++;
		} while (count > i);
		
		System.out.println();
		System.out.println("All student records updated!");
	}
}
