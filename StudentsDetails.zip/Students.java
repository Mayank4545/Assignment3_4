
public class Students {

	String name = null;
	int roll;
	int marks_math;
	int marks_science;
	int marks_english;
	
	public Students(String name, int roll, int marks_math, int marks_science, int marks_english) {
		super();
		this.name = name;
		this.roll = roll;
		this.marks_math = marks_math;
		this.marks_science = marks_science;
		this.marks_english = marks_english;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRoll() {
		return roll;
	}
	public void setRoll(int roll) {
		this.roll = roll;
	}
	public int getMarks_math() {
		return marks_math;
	}
	
//	Validation on marks. It can be only between 0 to 100
	
	public void setMarks_math(int marks_math) {
		if(marks_math >= 0 && marks_math <= 100){
			this.marks_math = marks_math;
		}else{
			System.out.println("Invalid Maths Marks!");
		}
		
	}
	public int getMarks_science() {
		return marks_science;
	}
	public void setMarks_science(int marks_science) {
		if(marks_science >= 0 && marks_science <= 100){
			this.marks_science = marks_science;
		}else{
			System.out.println("Invalid Science Marks!");
		}
	}
	public int getMarks_english() {
		return marks_english;
	}
	public void setMarks_english(int marks_english) {
		if(marks_english >= 0 && marks_english <= 100){
			this.marks_english = marks_english;
		}else{
			System.out.println("Invalid English Marks!");
		}
	}
}
